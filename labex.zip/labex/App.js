import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const resumeData = {
    imageUrl: require('./assets/profile.jpg'),
    name: 'TYMIE CINCO OLPINDO',
    course: 'Bachelor of Science in Information Technology',
    education: {
      elementary: 'Eulogio Rodriguez Elementary School',
      elementaryYear: '2014',
      highSchool: 'Caloocan High School',
      highSchoolYear: '2018',
      college: 'Global Reciprocal Colleges',
    },
    about: 'I am Tymie Cinco Olpindo, 22 years old, living in Caloocan City. I am in my 3rd year of college, taking a bachelor of science in information technology. I am the youngest in my family. I have three older brothers and one older sister. The reason why I am taking BSIT is because I want to gain more knowledge about technology, and technology nowadays is in demand. I am still learning about programming right now. Coding is not easy, but I will try my best to be the best. ',
  projects:
    {
      projectName:'Ordering, Sales and Inventory Management System',
      imageUrl: require('./assets/brewstea.jpg'),
      link: 'https://www.facebook.com/profile.php?id=61555399162340',
      description: 'This system will allow the business to maintain an online menu that customer can explore quickly and easily. This a web based ordering can benefit both the customer and the owner. ',
    },

    contact: {
    mobile: '09455214996',
    email: 'tymieolpindo072@gmail.com',
    },
  };

const handlePress = () => {
  setCurrentSection((prevSection) => {
    switch (prevSection) {
      case 'name':
        return 'education';
      case 'education':
        return 'about';
      case 'about':
        return 'projects'; 
      case 'projects':
        return 'contact'; 
      case 'contact':
        return 'name'; 
      default:
        return 'name';
    }
  });
};

     return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.contentContainer}>
          {currentSection === 'name' && (
            <>
              <Image source={resumeData.imageUrl} style={styles.image} />
              <View style={styles.textContainer}>
                <Text style={styles.header}>{resumeData.name}</Text>
                <Text style={styles.info}>{resumeData.course}</Text>
              </View>
            </>
          )}

          {currentSection === 'education' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>Education:</Text>
              <Text style={styles.projectTitle}>
                {'\n'}College:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.college}</Text>
                {' | '}
                {resumeData.education.collegeYear}
            
              <Text style={styles.projectTitle}>
                {'\n'}High School:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.highSchool}</Text>
                {' | '}
                {resumeData.education.highSchoolYear}
     
              <Text style={styles.projectTitle}>
                {'\n'}Elementary: 
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.elementary}</Text>
                {' | '}
                {resumeData.education.elementaryYear}
           
            </View>
          )}

          {currentSection === 'about' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>About me:{'\n'}</Text>
              <Text style={styles.about}>{resumeData.about}</Text>
            </View>
          )}

{currentSection === 'projects' && (
  <View style={styles.projectsContainer}>
    <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects.projectName}</Text>
    <Image source={{ uri: resumeData.projects.imageSrc }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects.link}</Text>
    <Text style={styles.projectDescription}> {resumeData.projects.description}</Text>
  </View>
)}

{currentSection === 'projects1' && (
  <View style={styles.projectsContainer}>
     <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects1.projectName1}</Text>
    <Image source={{ uri: resumeData.projects1.imageSrc1 }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects1.link1}</Text>
    <Text style={styles.projectDescription}>{resumeData.projects1.description1}</Text>
  </View>
)}

          {currentSection === 'contact' && (
            <View style={styles.contactContainer}>
              <Text style={styles.header1}>Contact Me:{'\n'}</Text>
              <Text style={styles.info1}>
                {'\n'}Mobile: {resumeData.contact.mobile}
                {'\n'}Email: {resumeData.contact.email}
              </Text>
            </View>
          )}

        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 25,
  },
  contentContainer: {
    alignItems: 'center',
    maxWidth: 600,
  },
  image: {
    width: 250,
    height: 275,
    borderRadius: 10,
    marginBottom: 10,
  },
  textContainer: {
    alignSelf: 'stretch',
  },
  header: {
    fontSize: 33,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'center',
  },
  header1: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  info: {
    fontSize: 20,
    alignSelf: 'flex-start',
    textAlign: 'center',
  },
  info1: {
    fontSize: 20,
    alignSelf: 'flex-start',
    textAlign: 'left',

  },
  about: {
    fontSize: 17,
    textAlign: 'left',
    alignSelf: 'flex-start',
  },
   projectsContainer: {
    alignSelf: 'stretch',
    marginTop: 20,
  },
  projectTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  projectImage: {
    width: 230,
    height: 230,
    marginBottom: 10,
    alignSelf: 'center',
  },
  projectLink: {
    fontSize: 13,
    marginBottom: 5,
    textAlign: 'center',
  },
  projectDescription: {
    fontSize: 15,
    marginBottom: 10,
    textAlign: 'justify',
  },


});

export default App;